local TopDownViewController = {}

TopDownViewController.name = "KoseiHelper/TopDownViewController"
TopDownViewController.depth = -9500
TopDownViewController.texture = "objects/KoseiHelper/Controllers/TopDownViewController"
TopDownViewController.placements = {
	{
		name = "Top Down View Controller",
		data = {
		}
	}
}

--return TopDownViewController
